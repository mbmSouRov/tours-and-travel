-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2021 at 11:22 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `travel`
--

-- --------------------------------------------------------

--
-- Table structure for table `contract`
--

CREATE TABLE `contract` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `message` varchar(255) NOT NULL,
  `text_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contract`
--

INSERT INTO `contract` (`id`, `name`, `email`, `phone`, `message`, `text_time`) VALUES
(1, 'gjuglc', 'aahasib.aust@gmail.com', '01766844304', '', '2021-03-26 19:38:39'),
(2, 'gjuglc', 'aahasib.aust@gmail.com', '01766844304', '', '2021-03-26 19:39:50'),
(8, 'Rakib', 'ikramulhasan42@gmail.com', '355236030528914', '		gzj\r\nzfhg\r\ndzguhjtg\r\nfzhgj		', '2021-03-28 15:14:27');

-- --------------------------------------------------------

--
-- Table structure for table `teampage`
--

CREATE TABLE `teampage` (
  `team_member_id` int(11) NOT NULL,
  `member_name` varchar(255) NOT NULL,
  `images` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teampage`
--

INSERT INTO `teampage` (`team_member_id`, `member_name`, `images`) VALUES
(0, 'Ashiq', 'bg.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `user_phone` varchar(20) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` text NOT NULL,
  `activation_code` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_phone`, `user_email`, `user_password`, `activation_code`, `status`, `created_date`, `updated_date`) VALUES
(1, 'Hasib', '01766844304', 'aahasib.aust@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', NULL, 1, '2021-03-22 02:47:00', '2021-03-28 00:00:00'),
(31, 'Hasib', '01766844304', 'ashiq@gmail.com', '202cb962ac59075b964b07152d234b70', NULL, 2, '2021-03-26 01:38:15', '2021-03-26 01:38:15'),
(33, 'hasib', '0176684', 'sizan@gmail.com', '202cb962ac59075b964b07152d234b70', NULL, 2, '2021-03-27 01:14:39', '2021-03-27 01:14:39'),
(34, 'Hasib', '01766844304', 'a@gmail.com', '9fe8593a8a330607d76796b35c64c600', NULL, 2, '2021-03-27 01:29:05', '2021-03-27 01:29:05'),
(35, 'Hasib', '01766844304', 'xjhg', '33ceb07bf4eeb3da587e268d663aba1a', NULL, 2, '2021-03-27 01:38:53', '2021-03-27 01:38:53'),
(36, 'Hasib', '01766844304', 'gh', '202cb962ac59075b964b07152d234b70', NULL, 2, '2021-03-27 02:07:16', '2021-03-27 02:07:16'),
(37, 'Hasib', '01766844304', 'tumi@gmail.com', '9fe8593a8a330607d76796b35c64c600', NULL, 2, '2021-03-27 02:07:49', '2021-03-27 02:07:49'),
(38, 'Hasib', '01766844304', 'tum@gmail.com', '202cb962ac59075b964b07152d234b70', NULL, 2, '2021-03-27 02:08:41', '2021-03-27 02:08:41');

-- --------------------------------------------------------

--
-- Table structure for table `x`
--

CREATE TABLE `x` (
  `phone` int(11) NOT NULL,
  `name` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `x`
--

INSERT INTO `x` (`phone`, `name`) VALUES
(456, 'Al-Hasib'),
(176684, 'Hasib');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contract`
--
ALTER TABLE `contract`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `x`
--
ALTER TABLE `x`
  ADD PRIMARY KEY (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contract`
--
ALTER TABLE `contract`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
